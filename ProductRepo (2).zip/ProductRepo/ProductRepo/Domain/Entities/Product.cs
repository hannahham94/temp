﻿using System;

namespace Domain.Entities
{
    public class Product
    {
        public int Id { get; set; }
        public string ActiveVersion { get; set; }
        public DateTime PostDate { get; set; }
        public string Description { get; set; }
        public string Title { get; set; }
    }
}
