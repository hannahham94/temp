﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Domain.Entities;
using MediatR;
using Newtonsoft.Json;

namespace Application.Products.Queries.GetProducts
{
    public class GetProductsQuery : IRequest<IEnumerable<ProductDto>>
    {
    }

    public class GetProductsQueryHandler : IRequestHandler<GetProductsQuery, IEnumerable<ProductDto>>
    {
        public Task<IEnumerable<ProductDto>> Handle(GetProductsQuery request, CancellationToken cancellationToken)
        {
            //Todo Step 1: Read in the Data.json file
            //Todo Step 2: Populate the ProductDto collection
            IEnumerable<ProductDto> lstItems = new List<ProductDto>();

            try
            {
                using (StreamReader r = new StreamReader("Data.json"))
                {
                    string json = r.ReadToEnd();
                    lstItems = JsonConvert.DeserializeObject<List<ProductDto>>(json);
                }
            }
            catch(Exception oEx)
            {
                //handle exception
                var test = oEx;
            }


            return Task.FromResult(lstItems);
        }
    }
}
