﻿using Application.Products.Queries.GetProducts;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace JobApplicationAPI.Controllers
{
    public class ProductController : ApiControllerBase
    {
        [HttpGet]
        public async Task<IEnumerable<ProductDto>> Get()
        {
            return await Mediator.Send(new GetProductsQuery());
        }
    }
}
