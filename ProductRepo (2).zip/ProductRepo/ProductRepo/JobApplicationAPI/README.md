# JrProject
# Todo Step 1: Read in the Data.json file
# Todo Step 2: Populate the ProductDto collection and return
# Todo Step 3: Bonus: Implement a UI in Winforms/React/WPF that shows the product data in a grid or cards